MWS Result File Version 20150206
size=i:115

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:surviveparchange
result=s:1
files=s:simulation_overview.json

type=s:DATA_FOLDER
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:rebuild
result=s:1
files=s:raw_data

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:rebuild
result=s:1
files=s:$SIMonItem$_1_0.s3d

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:rebuild
result=s:1
files=s:$SIMonInfo$.sin

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:rebuild
result=s:1
files=s:RefSpectrum_1.sig

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:rebuild
result=s:1
files=s:e-field (f=2.45)_1,1.m3d

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:rebuild
result=s:1
files=s:h-field (f=2.45)_1,1.m3d

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:solverstart
result=s:0
files=s:PBAMeshDetails.axg

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:solverstart
result=s:0
files=s:PBAConnectivity.axg

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:solverstart
result=s:0
files=s:PBAMeshFeedback.axg

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:survivemeshadapt
result=s:1
files=s:model.gex

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:survivemeshadapt
result=s:1
files=s:PP.sid

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:survivemeshadapt
result=s:1
files=s:PP.fmm

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:rebuild
result=s:0
files=s:ml_info.dat

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:rebuild
result=s:1
files=s:Port1_Info1[3.5].mmd

type=s:HIDDENITEM
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:rebuild
result=s:1
files=s:World.fid

type=s:FOLDER
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results

type=s:FOLDER
problemclass=s::8:1000
visibility=s:visible
creation=s:external
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Power\Excitation [1]\New Folder

type=s:XYSIGNAL
subtype=s:user
problemclass=s::4:3
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:Excitation Signals\default
files=s:signal_default_lf.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::0:0
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:Excitation Signals\default
files=s:signal_default.sig

type=s:MODEMAP
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:2D/3D Results\Port Modes\Port1\e1
files=s:Port1_e1.pmm
files=s:Port1_e1_pmm.rex
ylabel=s:Port1 e1

type=s:MODEMAP
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:2D/3D Results\Port Modes\Port1\h1
files=s:Port1_h1.pmm
files=s:Port1_h1_pmm.rex
ylabel=s:Port1 h1

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Port Information\Gamma\1(1)
files=s:Gamma_1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Port Information\Effective Dielectric Constant\1(1)
files=s:epseff_1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Port Information\Distance (-40 dB)\1(1)
files=s:decaydist_1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Port Information\Line Impedance\1(1)
files=s:zline_1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Port Information\Wave Impedance\1(1)
files=s:zwave_1(1).sig

type=s:MESH_FEEDBACK
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:solverstart
result=s:0
treepath=s:Mesh\Information\PBA
files=s:PBAMeshFeedback.rex
ylabel=s:Mesh Feedback

type=s:MESH_FEEDBACK
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:solverstart
result=s:0
treepath=s:Mesh\Information\Connectivity
files=s:PBAConnectivity.rex
ylabel=s:Mesh Feedback

type=s:MESH_FEEDBACK
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:solverstart
result=s:0
treepath=s:Mesh\Information\PBADetails
files=s:PBAMeshDetails.rex
ylabel=s:Mesh Feedback

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Power\Excitation [1]\Loss per Material\Metal loss in Copper (annealed)
files=s:cMetal_loss_Copper (annealed)(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Power\Excitation [1]\Loss in Metals
files=s:cTotal_metal_loss(1).sig

type=s:HFIELD3D
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:2D/3D Results\H-Field\h-field (f=2.45) [1]
files=s:h-field (f=2.45)_1,1.m3d
files=s:h-field (f=2.45)_1,1_m3d.rex

type=s:SURFACECURRENT
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:2D/3D Results\Surface Current\surface current (f=2.45) [1]
files=s:h-field (f=2.45)_1,1.m3d
files=s:h-field (f=2.45)_1,1_m3d_sct.rex

type=s:EFIELD3D
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:2D/3D Results\E-Field\e-field (f=2.45) [1]
files=s:e-field (f=2.45)_1,1.m3d
files=s:e-field (f=2.45)_1,1_m3d.rex

type=s:XYSIGNAL
subtype=s:time
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Port signals\i1
files=s:i1(1).sig

type=s:XYSIGNAL
subtype=s:time
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Port signals\o1,1
files=s:o1(1)1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\S-Parameters\S1,1
files=s:cS1(1)1(1).sig

type=s:XYSIGNAL
subtype=s:balance
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Balance\Balance [1]
files=s:1.bil

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Power\Excitation [1]\Power Stimulated
files=s:StimulatedPower_1.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Power\Excitation [1]\Power Outgoing all Ports
files=s:ReflectedPower_1.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Power\Excitation [1]\Power Accepted
files=s:AcceptedPower_1.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Power\Excitation [1]\Power Absorbed at all Ports
files=s:AbsorbedPower_1.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Power\Excitation [1]\Power Accepted per Port\Port 1
files=s:AcceptedPower_1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Power\Excitation [1]\Power Absorbed per Port\Port 1
files=s:AbsorbedPower_1(1).sig

type=s:XYSIGNAL
subtype=s:energy
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Energy\Energy [1]
files=s:1.eng

type=s:FARFIELD
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:Farfields\farfield (f=2.45) [1]
files=s:farfield (f=2.45)_1.ffm
ylabel=s:farfield (f=2.45) [1]

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Y Matrix\Y1,1
files=s:ycmplx1(1)1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Z Matrix\Z1,1
files=s:zcmplx1(1)1(1).sig

type=s:XYSIGNAL
subtype=s:linear
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\VSWR\VSWR1
files=s:vswr1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Power\Excitation [1]\Power Radiated
files=s:RadiatedPower_1.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Efficiencies\Rad. Efficiency [1]
files=s:FarfieldMetaData_1_RadEff.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Efficiencies\Tot. Efficiency [1]
files=s:FarfieldMetaData_1_TotEff.sig

type=s:FARFIELD1DCUT
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:Farfields\Farfield Cuts\Excitation [1]\Phi=0\farfield (f=2.45)
files=s:Farfield_Cut_farfield (f=2.45)_Phi=0_[1]_0.sig

type=s:FARFIELD1DCUT
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:Farfields\Farfield Cuts\Excitation [1]\Phi=90\farfield (f=2.45)
files=s:Farfield_Cut_farfield (f=2.45)_Phi=90_[1]_0.sig

type=s:FARFIELD1DCUT
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:Farfields\Farfield Cuts\Excitation [1]\Theta=90\farfield (f=2.45)
files=s:Farfield_Cut_farfield (f=2.45)_Theta=90_[1]_0.sig

type=s:PFIELD3D
problemclass=s::8:1000
visibility=s:visible
creation=s:external
lifetime=s:rebuild
result=s:1
user_delete=s:1
treepath=s:2D/3D Results\Power Flow\power (f=2.45) [1]
files=s:power (f=2.45)_1,1.m3d
files=s:power (f=2.45)_1.rex

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Reference Impedance\ZRef 1(1)
files=s:ZRef1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\Port Information\Port Modes_pmi\1(1)
files=s:Gamma_1(1)_pmi.sig

type=s:RESULT_0D
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:rebuild
result=s:1
treepath=s:1D Results\AutomaticRunInformation
files=s:AutomaticRunInformation

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Port Information\Gamma\1(1)
files=s:Gamma_1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Port Information\Effective Dielectric Constant\1(1)
files=s:epseff_1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Port Information\Distance (-40 dB)\1(1)
files=s:decaydist_1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Port Information\Line Impedance\1(1)
files=s:zline_1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Port Information\Wave Impedance\1(1)
files=s:zwave_1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Power\Excitation [1]\Loss per Material\Metal loss in Copper (annealed)
files=s:cMetal_loss_Copper (annealed)(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Power\Excitation [1]\Loss in Metals
files=s:cTotal_metal_loss(1).sig

type=s:XYSIGNAL
subtype=s:time
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Port signals\i1
files=s:i1(1).sig

type=s:XYSIGNAL
subtype=s:time
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Port signals\o1,1
files=s:o1(1)1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\S-Parameters\S1,1
files=s:cS1(1)1(1).sig

type=s:XYSIGNAL
subtype=s:balance
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Balance\Balance [1]
files=s:1.bil

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Power\Excitation [1]\Power Stimulated
files=s:StimulatedPower_1.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Power\Excitation [1]\Power Outgoing all Ports
files=s:ReflectedPower_1.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Power\Excitation [1]\Power Accepted
files=s:AcceptedPower_1.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Power\Excitation [1]\Power Absorbed at all Ports
files=s:AbsorbedPower_1.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Power\Excitation [1]\Power Accepted per Port\Port 1
files=s:AcceptedPower_1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Power\Excitation [1]\Power Absorbed per Port\Port 1
files=s:AbsorbedPower_1(1).sig

type=s:XYSIGNAL
subtype=s:energy
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Energy\Energy [1]
files=s:1.eng

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Y Matrix\Y1,1
files=s:ycmplx1(1)1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Z Matrix\Z1,1
files=s:zcmplx1(1)1(1).sig

type=s:XYSIGNAL
subtype=s:linear
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\VSWR\VSWR1
files=s:vswr1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Power\Excitation [1]\Power Radiated
files=s:RadiatedPower_1.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Efficiencies\Rad. Efficiency [1]
files=s:FarfieldMetaData_1_RadEff.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Efficiencies\Tot. Efficiency [1]
files=s:FarfieldMetaData_1_TotEff.sig

type=s:FARFIELD1DCUT
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:Farfields\Farfield Cuts\Excitation [1]\Phi=0\farfield (f=2.45)
files=s:Farfield_Cut_farfield (f=2.45)_Phi=0_[1]_0.sig

type=s:FARFIELD1DCUT
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:Farfields\Farfield Cuts\Excitation [1]\Phi=90\farfield (f=2.45)
files=s:Farfield_Cut_farfield (f=2.45)_Phi=90_[1]_0.sig

type=s:FARFIELD1DCUT
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:Farfields\Farfield Cuts\Excitation [1]\Theta=90\farfield (f=2.45)
files=s:Farfield_Cut_farfield (f=2.45)_Theta=90_[1]_0.sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Reference Impedance\ZRef 1(1)
files=s:ZRef1(1).sig

type=s:XYSIGNAL
subtype=s:complex
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\Port Information\Port Modes_pmi\1(1)
files=s:Gamma_1(1)_pmi.sig

type=s:RESULT_0D
problemclass=s::8:1000
visibility=s:hidden
creation=s:internal
lifetime=s:surviveparchange
result=s:1
parametric=s:P
treepath=s:1D Results\AutomaticRunInformation
files=s:AutomaticRunInformation

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\Cotton\Dispersive\Eps'
files=s:Cotton_eps_re.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\Cotton\Dispersive\Eps''
files=s:Cotton_eps_im.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\Cotton\Dispersive\Eps TangD
files=s:Cotton_eps_tgd.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\FAT\Dispersive\Eps'
files=s:FAT_eps_re.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\FAT\Dispersive\Eps''
files=s:FAT_eps_im.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\FAT\Dispersive\Eps TangD
files=s:FAT_eps_tgd.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\MUSCLE\Dispersive\Eps'
files=s:MUSCLE_eps_re.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\MUSCLE\Dispersive\Eps''
files=s:MUSCLE_eps_im.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\MUSCLE\Dispersive\Eps TangD
files=s:MUSCLE_eps_tgd.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\SKIN\Dispersive\Eps'
files=s:SKIN_eps_re.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\SKIN\Dispersive\Eps''
files=s:SKIN_eps_im.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\SKIN\Dispersive\Eps TangD
files=s:SKIN_eps_tgd.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\fat\Dispersive\Eps'
files=s:fat_eps_re.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\fat\Dispersive\Eps''
files=s:fat_eps_im.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\fat\Dispersive\Eps TangD
files=s:fat_eps_tgd.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\muscle\Dispersive\Eps'
files=s:muscle_eps_re.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\muscle\Dispersive\Eps''
files=s:muscle_eps_im.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\muscle\Dispersive\Eps TangD
files=s:muscle_eps_tgd.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\skin\Dispersive\Eps'
files=s:skin_eps_re.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\skin\Dispersive\Eps''
files=s:skin_eps_im.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\skin\Dispersive\Eps TangD
files=s:skin_eps_tgd.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\Copper (annealed)\Surface Impedance\Z' (Fit)
files=s:Copper (annealed)_Z_re.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\Copper (annealed)\Surface Impedance\Z'' (Fit)
files=s:Copper (annealed)_Z_im.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\Copper (annealed)\Surface Impedance\Z' (Theory)
files=s:Copper (annealed)_Z_datalist_re.sig

type=s:XYSIGNAL
subtype=s:user
problemclass=s::8:1000
visibility=s:visible
creation=s:internal
lifetime=s:persistent
result=s:0
treepath=s:1D Results\Materials\Copper (annealed)\Surface Impedance\Z'' (Theory)
files=s:Copper (annealed)_Z_datalist_im.sig

